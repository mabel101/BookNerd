// Mable Chileshe
// this is the genre's class that contains the methods
// and how the collection of books will be created and categorised in genres using
// java list

import java.util.*;
public class genres {
    public static void main (String [] args) {
        ArrayList<String> list = new ArrayList<String>(); // creating arraylist
        list.add("block the blessing"); // adding object or book to list
        list.add("the heir");
        list.add("over comer");
        list.add("war room");

        String removedStr = list.remove(1); // removing object or book from list or collection

        //Transversing list through iterator
        // with the iterator, the objects in the list are printed on individual lines

        Iterator itr = list.iterator(); //generating the iterator
        while (itr.hasNext()){ // checking if iterator has elements
            System.out.println(itr.next()); //printing elements in the list and move to the next

        }



    }
}

