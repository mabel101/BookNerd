import junit.framework.TestCase;

public class adminTest extends TestCase {

    public void setUp() throws Exception {
        super.setUp();
    }

    public void tearDown() throws Exception {



    }
}