// Mable Chileshe
// main program that will run on user's device after the program is installed

import javax.swing.*;
import java.util.Scanner;

public class main_program {
    public static void main (String [] args){
        System.out.println(
                "hello dear user😊💕💕💕\n" +
                        "welcome to Book Nerd, the universal library for book worms\n" +
                        "our application provides recommendations for book titles as per genre\n" +
                        "and gives you the option of adding your favourite books to the wish list\n" +
                        "\nHappy Reading😉💖\n");

        // menu bar showing app features
        JMenu menu;
        JMenuItem i1, i2, i3, i4, i5;

        JFrame f= new JFrame("Book Nerd📚");
        JMenuBar mb=new JMenuBar();
        menu=new JMenu("Available Book Genres");
//        submenu=new JMenu("Sub Menu");
        i1=new JMenuItem("Sci-Fiction");
        i2=new JMenuItem("fiction");
        i3=new JMenuItem("Horror");
        i4=new JMenuItem("Short stories");
        i5=new JMenuItem("Fantasy");
        menu.add(i1); menu.add(i2); menu.add(i3); menu.add(i4); menu.add(i5);

        mb.add(menu);
        f.setJMenuBar(mb);
        f.setSize(200,250);
        f.setLayout(null);
        f.setVisible(true);





        Scanner Scanner = new Scanner(System.in);

        System.out.println(
                "To get a recommendation, chose your genre by entering the required number:\n" +
                        "1 : Sci-Fiction\n" +
                        "2 : Fiction\n" +
                        "3 : Horror\n" +
                        "4 : Short Stories" +
                        "5 : Fantasy & Adventure");

        int option = Scanner.nextInt();
//        System.out.println("you have chosen: " + option);

        if (option == 1) {
            System.out.println("        Sci-Fiction\n" +
                    "---------------------------------------------\n" +
                    "Kindred - Octavia Butler\n" +
                    "The moon is a Hash Mistress - Robert Heinlen\n" +
                    "The left hand of darkness - Ursula Le Guin\n" +
                    "A Scanner Darkly - Philip K Dick\n" +
                    "The Stars, My Destination - Susan Cooper\n" +
                    "The Blazing World - Margaret  Cavendish\n" +
                    "Solaris - Stanisla lem\n" +
                    "Frankenstein - Mary Shelley\n" +
                    "The Dark Is Rising - Stephen King\n");
        }
        else if (option == 2) {
            System.out.println("   🎆 Fiction\n" +
                    "----------------------------------------------\n" +
                    "All quiet on the Western Front - Eric Maria\n" +
                    "The color Purple - Alice Walker\n" +
                    "The Alchemist - Paulo Coelho\n" +
                    "Anne of Green Gabbles - Lucy Maud\n" +
                    "The Vegetarian - Han Kang\n" +
                    "A town Like Alice - Nevil Shute\n" +
                    "Americanah - Chimamanda Ngozi Adichie\n" +
                    "Lord Of The Flies - William Golding\n" +
                    "A Tale Of Two Cities - Charlotte Bronte\n" +
                    "The Paying Gestets - Sarah Waters ");

        }
        else if (option == 3) {
            System.out.println("    🎆 HORROR\n" +
                    "-------------------------------------------------\n" +
                    "Terrifying Tales - Edgar Allan Poe\n" +
                    "House Of Leaves - Mark Danielewski\n" +
                    "Rosemary's Baby - Ira Levin\n" +
                    "The Haunting oF Hill House - Shirley Jackson\n" +
                    "Lord Of The Flies - William Golding\n" +
                    "We need To Talk About Kevin - Lionel Shriver\n" +
                    "Night Film - Marisha Pessl\n" +
                    "Ring, Koji - Su Zuki\n" +
                    "PenPal - Dathan Auerbach\n" +
                    "Carrion Comfort - Dan Simmons \n" +
                    "Pet Semetry - Stephen King");
        }
        else if (option == 4) {
            System.out.println("🎆 FANTASY AND ADVENTURE\n" +
                    "----------------------------------------------------\n" +
                    "Alice's Adventures In Wonderland - Lewis Carrol\n" +
                    "The King of Elfland's Daughter - Lord Dunsany\n" +
                    "The Sword in the stone - T.H White\n" +
                    "The Lion, The Witch, and the Wadrobe - CS Lewis\n" +
                    "The master and Margarita - Mikhaol Bulgakov \n" +
                    "The Last Unicorn - Peter. S Beagle \n" +
                    "A Wizard Of EarthSea - Ursular Le Guin \n" +
                    "The fellowship of the Ring - J.R.R Tolkien \n" +
                    "Watership Down - Richard Adams \n" +
                    "The Dark is Rising - Susan Cooper");

        }
        else {
            System.out.println("Sorry, your chosen genre is not found in our collection. try another one");
        }

// if the user wants to see other book genres
// the program to redirect them back to the main menu and repeat the process

        System.out.println("\n \npress 1 if you would like to see other book collections\n" +
                "or press 0 to exit");
        int input = Scanner.nextInt();
//        System.out.println("you have opted to :" + input);

        if (input == 1) {
            System.out.println("you are being redirected to the main menu\n");



            System.out.println(
                    "To get a recommendation, chose your genre by entering the required number:\n" +
                            "1 : Sci-Fiction\n" +
                            "2 : Fiction\n" +
                            "3 : Horror\n" +
                            "4 : Short Stories" +
                            "5 : Fantasy & Adventure");
            int option2 = Scanner.nextInt();


            if (option2 == 1) {
                System.out.println("        Sci-Fiction\n" +
                        "---------------------------------------------\n" +
                        "Kindred - Octavia Butler\n" +
                        "The moon is a Hash Mistress - Robert Heinlen\n" +
                        "The left hand of darkness - Ursula Le Guin\n" +
                        "A Scanner Darkly - Philip K Dick\n" +
                        "The Stars, My Destination - Susan Cooper\n" +
                        "The Blazing World - Margaret  Cavendish\n" +
                        "Solaris - Stanisla lem\n" +
                        "Frankenstein - Mary Shelley\n" +
                        "The Dark Is Rising - Stephen King\n");
            }
            else if (option2 == 2) {
                System.out.println("   🎆 Fiction\n" +
                        "----------------------------------------------\n" +
                        "All quiet on the Western Front - Eric Maria\n" +
                        "The color Purple - Alice Walker\n" +
                        "The Alchemist - Paulo Coelho\n" +
                        "Anne of Green Gabbles - Lucy Maud\n" +
                        "The Vegetarian - Han Kang\n" +
                        "A town Like Alice - Nevil Shute\n" +
                        "Americanah - Chimamanda Ngozi Adichie\n" +
                        "Lord Of The Flies - William Golding\n" +
                        "A Tale Of Two Cities - Charlotte Bronte\n" +
                        "The Paying Gestets - Sarah Waters ");

            }
            else if (option2 == 3) {
                System.out.println("    🎆 HORROR\n" +
                        "-------------------------------------------------\n" +
                        "Terrifying Tales - Edgar Allan Poe\n" +
                        "House Of Leaves - Mark Danielewski\n" +
                        "Rosemary's Baby - Ira Levin\n" +
                        "The Haunting oF Hill House - Shirley Jackson\n" +
                        "Lord Of The Flies - William Golding\n" +
                        "We need To Talk About Kevin - Lionel Shriver\n" +
                        "Night Film - Marisha Pessl\n" +
                        "Ring, Koji - Su Zuki\n" +
                        "PenPal - Dathan Auerbach\n" +
                        "Carrion Comfort - Dan Simmons \n" +
                        "Pet Semetry - Stephen King");
            }
            else if (option2 == 4) {
                System.out.println("🎆 FANTASY AND ADVENTURE\n" +
                        "----------------------------------------------------\n" +
                        "Alice's Adventures In Wonderland - Lewis Carrol\n" +
                        "The King of Elfland's Daughter - Lord Dunsany\n" +
                        "The Sword in the stone - T.H White\n" +
                        "The Lion, The Witch, and the Wadrobe - CS Lewis\n" +
                        "The master and Margarita - Mikhaol Bulgakov \n" +
                        "The Last Unicorn - Peter. S Beagle \n" +
                        "A Wizard Of EarthSea - Ursular Le Guin \n" +
                        "The fellowship of the Ring - J.R.R Tolkien \n" +
                        "Watership Down - Richard Adams \n" +
                        "The Dark is Rising - Susan Cooper");

            }
            else {
                System.out.println("Sorry, your chosen genre is not found in our collection. try another one");
            }



        }
        else{
            System.out.println("thank you for visiting book nerd! \n" +
                    "we hope you were fascinated by one or more book titles\n" +
                    "that you can add to your book list");

        }












    }

}
