//Mable
// this is the admin class through which the admin or owner of the application can
// add, remove or update books to the list of book genres stored in the system
// the admin is also in charge of the genre's class and can therefore perform the actions
// listed in the genre's class

import javax.swing.*;

public class admin {
    public static void main (String[] args){

        System.out.println(
                "hello dear Admin😊💕💕💕\n" +
                "Thank you for making Book Worm a real time unicorn for book lovers!\n" +
                "This is your admin account where you can add, delete or update books to\n" +
                "the collection of books available on the platform\n" +
                "\nHappy Reading😉💖");

        // menu bar showing admin menu screen
        JMenu menu;
        JMenuItem i1, i2, i3, i4, i5;

        JFrame f= new JFrame("Book Nerd📚");
        JMenuBar mb=new JMenuBar();
        menu=new JMenu("Admin Control Pannel");
//        submenu=new JMenu("Sub Menu");
        i1=new JMenuItem("add books");
        i2=new JMenuItem("update books");
        i3=new JMenuItem("delete book(s)");
        i4=new JMenuItem("change app theme");
        i5=new JMenuItem("delete application");
        menu.add(i1); menu.add(i2); menu.add(i3); menu.add(i4); menu.add(i5);

        mb.add(menu);
        f.setJMenuBar(mb);
        f.setSize(200,2500);
        f.setLayout(null);
        f.setVisible(true);


    }
}
