import junit.framework.TestCase;

public class genresTest extends TestCase {

    public void setUp() throws Exception {
        super.setUp();
    }

    public void tearDown() throws Exception {
    }

    public void testMain() {
    }
}