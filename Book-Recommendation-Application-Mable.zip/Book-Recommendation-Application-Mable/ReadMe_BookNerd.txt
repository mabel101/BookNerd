BookNerd, 
this application gives you recommendations of book titles with their respective aurthors.
the application gives recommedations in the following genres; fiction, sci-fiction,horror and fantasy/adventure.
this application is very easy to use
simply unzip the package and double click on the file named "Book_Recommendation_Mable" with the blue windows icon.
or you can altenatively right click and then opt to 'view as administrator
the application will then be automatically installed on your computer, ready for you to explore!
No need to sign up or log in!

Happy Reading😊
